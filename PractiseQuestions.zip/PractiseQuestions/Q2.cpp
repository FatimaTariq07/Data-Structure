#include <iostream>
using namespace std;
int main()
{
    int number;
    cout << "Enter a number: ";
    cin >> number;
    int reverse;
    for (int i = 0; i < 3; i++)
    {
        reverse = number % 10;
        cout << reverse;
        number = number / 10;
    }
    return 0;
}