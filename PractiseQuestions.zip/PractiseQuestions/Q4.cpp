#include <iostream>
using namespace std;
int main()
{
    int radius;
    cout << "Enter the radius of the circle: ";
    cin >> radius;
    int diameter = radius * 2;
    cout << "Diameter of the circle is: " << diameter << endl;
    int circumference = 2 * 3.14 * radius;
    cout << "Circumference of the circle is: " << circumference << endl;
    int area = 3.14 * radius * radius;
    cout << "Area of the circle is: " << area << endl;
}