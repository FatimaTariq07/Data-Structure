#include <iostream>
using namespace std;
int main()
{
  int num1;
  int num2;
  cout << "Enter the number: ";
  cin >> num1;
  cout << "Enter 2nd number: ";
  cin >> num2;
  int temp;
  temp = num1;
  num1 = num2;
  num2 = temp;
  cout << "Number after swapping " << num1 << " and " << num2;
  return 0;
}