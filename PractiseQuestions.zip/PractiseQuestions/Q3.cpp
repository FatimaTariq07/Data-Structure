#include <iostream>
using namespace std;
int main()
{
    int number;
    cout << "Enter a number: ";
    cin >> number;
    int sum = 0;
    int reverse = 0;
    while (number > 0)
    {
        reverse = reverse * 10;
        reverse = reverse + number % 10;
        sum = sum + number % 10;
        number = number / 10;
    }
    while (reverse > 0)
    {
        cout << reverse % 10 << " , ";
        reverse = reverse / 10;
    }
    cout << endl;
    cout << sum << endl;
    return 0;
}